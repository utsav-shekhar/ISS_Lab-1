#3c:

cat sample.txt | wc -w
