# 3a: 
wc -c < sample.txt


