grep -v '^$' sample.txt > output.txt

sort output.txt | uniq -i >finaloutput.txt



