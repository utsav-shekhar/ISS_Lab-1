sed -e 's/[^[:alpha:]]/ /g' $1 | tr '\n' " " |  tr -s " " | tr " " '\n'|
tr 'A-Z' 'a-z' |
sort | uniq -cd | awk '{print "Word : <"$2"> - Count of repetition :["$1-1"]"}'
