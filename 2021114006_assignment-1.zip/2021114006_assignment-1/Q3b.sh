#3b:

cat sample.txt | wc -l
