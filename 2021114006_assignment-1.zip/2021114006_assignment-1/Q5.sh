#Q5a:
read -p "Enter a string: " str
length=${#str}
i=$((length-1))
while [ $i -ge 0 ]
do
        revstr=$revstr${str:$i:1}
        i=$((i-1))
done
echo "Reverse of $str is $revstr"
#Q5b:
read -p "Enter the string : " str 

str=$(echo "$str" | tr "0-9A-z" "1-9A-z_")
echo "$str"
#Q5c:
echo "enter the string:"
read str
n=${#str}
for ((i=$n/2-1; i>=0;i--))
    do
ch=${str:i:1}
echo -n $ch
     done
for ((i=$n/2; i<n;i++))
    do
ch=${str:i:1}
echo -n $ch
     done
echo ""



